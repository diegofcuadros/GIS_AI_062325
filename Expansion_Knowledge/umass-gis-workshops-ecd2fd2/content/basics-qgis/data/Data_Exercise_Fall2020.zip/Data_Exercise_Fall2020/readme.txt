The folder MAHolyokeChicopee1937 contains a shapefile of the Home Owners' Loan Corporation map of the cities of Holyoke and Chicopee, MA. It was downloaded from the Mapping Inequality: Redlining in New Deal America project (https://dsl.richmond.edu/panorama/redlining/#loc=5/39.1/-94.58&text=downloads).

The folder MA_precincts_12_16 contains a shapefile of the voting precincts in Massachusetts along with results frmo the 2012 and 2016 presidential elections. The data were located on the OpenPrecincts data portal (https://openprecincts.org/ma/) and downloaded from the Metric Geometry and Gerrymandering Group (MGGG) GitHub repository (https://github.com/mggg-states/MA-shapefiles).


Rebecca M. Seifried
(rseifried@umass.edu)
27 October 2020